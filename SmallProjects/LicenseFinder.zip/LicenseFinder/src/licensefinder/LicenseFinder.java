package licensefinder;

//JENA
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.NodeIterator;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.ResIterator;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.util.FileManager;

//JAVA
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;

//LOG4J
import org.apache.log4j.Level;
import org.apache.log4j.varia.NullAppender;

/**
 *
 * @author Victor
 */
public class LicenseFinder {

    //Obtenida haciendo esta consulta a la API del CKAN.
    //http://thedatahub.org/api/search/dataset?q=groups%3Alodcloud&limit=340
    static String LODCLOUD[]={
    "2000-us-census-rdf",
"aemet",
"agrovoc-skos",
"amsterdam-museum-as-edm-lod",
"archiveshub-linkeddata",
"austrian_ski_racers",
"b3kat",
"bbc-music",
"bbc-programmes",
"bbc-wildlife-finder",
"beneficiaries-of-the-european-commission",
"bibbase",
"bible-ontology",
"bio2rdf-affymetrix",
"bio2rdf-cas",
"bio2rdf-chebi",
"bio2rdf-genbank",
"bio2rdf-goa",
"bio2rdf-hgnc",
"bio2rdf-homologene",
"bio2rdf-interpro",
"bio2rdf-kegg-compound",
"bio2rdf-kegg-drug",
"bio2rdf-kegg-enzyme",
"bio2rdf-kegg-glycan",
"bio2rdf-kegg-pathway",
"bio2rdf-kegg-reaction",
"bio2rdf-mgi",
"bio2rdf-ncbi-gene",
"bio2rdf-obo",
"bio2rdf-omim",
"bio2rdf-pdb",
"bio2rdf-pfam",
"bio2rdf-prodom",
"bio2rdf-prosite",
"bio2rdf-pubchem",
"bio2rdf-pubmed",
"bio2rdf-reactome",
"bio2rdf-sgd",
"bio2rdf-unists",
"bluk-bnb",
"brazilian-politicians",
"bricklink",
"british-museum-collection",
"business-data-gov-uk",
"calames",
"chem2bio2rdf",
"chronicling-america",
"clean-energy-data-reegle",
"colinda",
"core",
"cornetto",
"data-bnf-fr",
"data-cnr-it",
"data-gov",
"data-gov-ie",
"data-gov-uk-time-intervals",
"data-incubator-climb",
"data-incubator-discogs",
"data-incubator-metoffice",
"data-incubator-moseley",
"data-incubator-musicbrainz",
"data-incubator-nasa",
"data-incubator-our-airports",
"data-incubator-pokedex",
"data-incubator-smcjournals",
"data-open-ac-uk",
"datos-bcn-cl",
"datos-bne-es",
"dbpedia",
"dbpedia-el",
"dbpedia-lite",
"dbpedia-pt",
"dbtropes",
"dbtune-artists-last-fm",
"dbtune-audioscrobbler",
"dbtune-classical",
"dbtune-john-peel-sessions",
"dbtune-magnatune",
"dbtune-musicbrainz",
"dbtune-myspace",
"dcs-sheffield",
"deutsche-biographie",
"dewey_decimal_classification",
"didactalia",
"dnb-gemeinsame-normdatei",
"ecco-tcp-linked-data",
"ecs",
"education-data-gov-uk",
"educationalprograms_sisvu",
"eea",
"enakting-co2emission",
"enakting-crime",
"enakting-energy",
"enakting-mortality",
"enakting-nhs",
"enakting-population",
"enipedia",
"environmental-applications-reference-thesaurus",
"esd-standards",
"eu-institutions",
"eumida-linked-data",
"eunis",
"europeana-lod",
"eurostat-rdf",
"eutc-productions",
"event-media",
"fanhubz",
"fao-geopolitical-ontology",
"farmbio-chembl",
"farmers-markets-geographic-data-united-states",
"finnish-municipalities",
"fishes-of-texas",
"flickr-wrappr",
"freebase",
"fu-berlin-cordis",
"fu-berlin-dailymed",
"fu-berlin-dblp",
"fu-berlin-diseasome",
"fu-berlin-drugbank",
"fu-berlin-eures",
"fu-berlin-eurostat",
"fu-berlin-medicare",
"fu-berlin-project-gutenberg",
"fu-berlin-sider",
"fu-berlin-stitch",
"gemeenschappelijke-thesaurus-audiovisuele-archieven",
"gemet",
"geolinkeddata",
"geological-survey-of-austria-thesaurus",
"geonames-semantic-web",
"geospecies",
"geowordnet",
"gesis-thesoz",
"gnoss",
"googleart-wrapper",
"government-web-integration-for-linked-data",
"govtrack",
"grrp",
"hellenic-fire-brigade",
"hellenic-police",
"hungarian-national-library-catalog",
"idreffr",
"iserve",
"istat-immigration",
"italian-public-schools-linkedopendata-it",
"jamendo-dbtune",
"japan-radioactivity-stat",
"john-goodwins-family-tree",
"klappstuhlclub",
"knoesis-linked-sensor-data",
"l3s-dblp",
"lcsh",
"lexvo",
"libris",
"libver",
"lichfield-spending",
"lingvoj",
"linked-crunchbase",
"linked-edgar",
"linked-eurostat",
"linked-open-data-of-ecology",
"linked-open-numbers",
"linked-open-vocabularies-lov",
"linked-user-feedback",
"linkedct",
"linkedgeodata",
"linkedlccn",
"linkedmdb",
"lista-encabezamientos-materia",
"lobid-organisations",
"lobid-resources",
"loc",
"loius",
"london-gazette",
"los_metar",
"lotico",
"manchester-university-reading-lists",
"marc-codes",
"meducator",
"morelab",
"museums-in-italy",
"my-experiment",
"my-family-lineage",
"national-diet-library-authorities",
"nomenclator-asturias-2010",
"normesh",
"nottingham-trent-university-resource-lists",
"ntnusc",
"nvd",
"nytimes-linked-open-data",
"oceandrilling-codices",
"oceandrilling-janusamp",
"oclc-fast",
"ogolod",
"ontos-news-portal",
"open-data-thesaurus",
"open-election-data-project",
"open-energy-info-wiki",
"opencalais",
"opencorporates",
"opencyc",
"openlibrary",
"openlylocal",
"ordnance-survey-linked-data",
"oxpoints",
"patents-data-gov-uk",
"pleiades",
"pokepedia-fr",
"prefix-cc",
"printed-book-auction-catalogues",
"productdb",
"productontology",
"pscs-catalogue",
"psh-subject-headings",
"radatana",
"rdf-book-mashup",
"rdfize-lastfm",
"rdfohloh",
"rechtspraak",
"reference-data-gov-uk",
"renewable_energy_generators",
"research-data-gov-uk",
"revyu",
"riese",
"rkb-explorer-acm",
"rkb-explorer-budapest",
"rkb-explorer-citeseer",
"rkb-explorer-cordis",
"rkb-explorer-courseware",
"rkb-explorer-crime",
"rkb-explorer-curriculum",
"rkb-explorer-darmstadt",
"rkb-explorer-dblp",
"rkb-explorer-deepblue",
"rkb-explorer-deploy",
"rkb-explorer-dotac",
"rkb-explorer-ecs",
"rkb-explorer-eprints",
"rkb-explorer-era",
"rkb-explorer-eurecom",
"rkb-explorer-ft",
"rkb-explorer-ibm",
"rkb-explorer-ieee",
"rkb-explorer-irit",
"rkb-explorer-jisc",
"rkb-explorer-kisti",
"rkb-explorer-laas",
"rkb-explorer-newcastle",
"rkb-explorer-nsf",
"rkb-explorer-oai",
"rkb-explorer-os",
"rkb-explorer-pisa",
"rkb-explorer-rae2001",
"rkb-explorer-resex",
"rkb-explorer-risks",
"rkb-explorer-roma",
"rkb-explorer-southampton",
"rkb-explorer-ulm",
"rkb-explorer-unlocode",
"rkb-explorer-wiki",
"rkb-explorer-wordnet",
"schemapedia",
"scholarometer",
"scotland-pupil-numbers-and-exam-results-2008",
"scotland-statistical-geography",
"sears",
"sec-rdfabout",
"secold",
"semantic-web-dog-food",
"semantic-xbrl",
"semantictweet",
"semanticweb-org",
"semsol-crunchbase",
"slideshare2rdf",
"smartlink",
"socialsemweb-thesaurus",
"southampton-ecs-eprints",
"st-andrews-resource-lists",
"statistics-data-gov-uk",
"stitch-rameau",
"stw-thesaurus-for-economics",
"sudocfr",
"surge-radio",
"swedish-open-cultural-heritage",
"sweto-dblp",
"sztaki-lod",
"t4gm-info",
"tags2con-delicious",
"talis-openlibrary",
"taxonconcept",
"tcmgenedit_dataset",
"telegraphis",
"temple-ov-thee-lemur-datasets",
"the-view-from",
"thesaurus-w",
"thesesfr",
"traffic-scotland",
"transparency-linked-data",
"transport-data-gov-uk",
"twarql",
"twc-logd",
"ub-mannheim-linked-data",
"uberblic",
"uk-legislation-api",
"uk-postcodes",
"umbel",
"uniprot",
"uniprot-taxonomy",
"uniprot-uniparc",
"uniprot-unipathway",
"uniprotkb",
"uniref",
"university-plymouth-reading-lists",
"university-sussex-reading-lists",
"uriburner",
"viaf",
"vivo-cornell-university",
"vivo-indiana-university",
"vivo-university-of-florida",
"vu-wordnet",
"w3c-wordnet",
"webnmasunotraveler",
"world-bank-linked-data",
"world-factbook-fu-berlin",
"yago",
"yahoo_geoplanet",
"yovisto",
"zaragoza-turismo",
"zbw-pressemappe20",
"zhishi-me",
"zitgist-musicbrainz"};

    public static HashMap<String, String> map = new HashMap<String, String>();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //ME QUITO LOS COMENTARIOS DE LOG4J
        org.apache.log4j.BasicConfigurator.configure(new NullAppender());

        LicenseFinder lf = new LicenseFinder();
        lf.ejecutar();
    }

    public void ejecutar()
    {
        List<String> archivos=LicenseFinder.getLODCloudFileNames();
        //OBTENGO LOS ARCHIVOS EN LA CARPETA
        for(String s : archivos)
        {
            String lic = parser("rdf/"+s);
            String lds=s.substring(0,s.length()-4);
            map.put(lds, lic);
        }
        
    }
    
    public static String getLastBitFromUrl(final String url){
        return url.replaceFirst(".*/([^/?]+).*", "$1");
    }    

    public List<String> getFileNamesInFolder(String sfolder)
    {
        List<String> lista=new ArrayList<String>();
         File folder = new File(sfolder);
            File[] listOfFiles = folder.listFiles();

            for (int i = 0; i < listOfFiles.length; i++) {
              if (listOfFiles[i].isFile()) {
                  String archivo=listOfFiles[i].getName();
                  lista.add(archivo);
              } else if (listOfFiles[i].isDirectory()){}
            }
            return lista;        
    }
    
    /**
     * Obtiene los nombres de las pelotas a partir de la lista.
     */
    public static List<String> getLODCloudFileNames()
    {
        List<String> lista=new ArrayList<String>();
        for(String s : LODCLOUD)
        {
            s=s+".rdf";
            lista.add(s);
        }
        return lista;
        /*
         File folder = new File("rdf");
         File[] listOfFiles = folder.listFiles();

            for (int i = 0; i < listOfFiles.length; i++) {
              if (listOfFiles[i].isFile()) {
                  String archivo=listOfFiles[i].getName();
                  lista.add(archivo);
//                System.out.println("File " + listOfFiles[i].getName());
              } else if (listOfFiles[i].isDirectory()) {
               // System.out.println("Directory " + listOfFiles[i].getName());
              }
            }
            return lista;*/
    }
    
    /**
     * Parsea un archivo RDF e indica su licencia
     */
    String parser(String fileNameOrUri) {
        System.err.println("Parsing: " + fileNameOrUri);
        try {
//            org.apache.log4j.BasicConfigurator.configure();
            File f=new File(fileNameOrUri);
            String nameext=f.getName();
            String filename=nameext.substring(0,nameext.length()-4);
            
            Model model = ModelFactory.createDefaultModel();
            InputStream is = FileManager.get().open(fileNameOrUri);
            if (is != null) {
                model.read(is, null);
                String URIdataset = "http://www.w3.org/ns/dcat#DataSet";
                String URIrights = "http://purl.org/dc/terms/rights";
                Resource Rdataset = model.getResource(URIdataset);
                Property Prights = model.getProperty(URIrights);

                Statement st2 = model.getProperty(Rdataset, Prights);

                ResIterator it = model.listSubjects();
                NodeIterator nodit = model.listObjects();
                StmtIterator propIt = null;
                Resource res = null;

                it = model.listSubjectsWithProperty(Prights);
                while (it.hasNext()) {
                    res = it.next();
                    String nombre=getLastBitFromUrl(res.toString());
                    if (nombre.equals(filename))
                    {
                        String derechos=res.getPropertyResourceValue(Prights).toString();
                        System.out.println(nombre  + "\t"  + derechos);
                        is.close();
                        return derechos;
                    }
                }
                System.out.println(filename  + "\tNADA");
                //   model.write(System.out, "TURTLE");
            } else {
                System.err.println("cannot read " + fileNameOrUri);;
                return "error";
            }
        } catch (Exception e) {
            
            System.err.println("MIENTRAS PROCESABA... " + fileNameOrUri);
            e.printStackTrace();
            return "error";
        }
        return "";
    }
}
